import numpy as np

from src.similarity import SimilarityIndex


def test_similarity_index_finds_exact_match():
    reference_texts = ["great product", "terrible product", "average product"]
    reference_embeddings = np.array(
        [
            [1.0, 0.0],
            [0.0, 1.0],
            [0.7, 0.7],
        ]
    )
    index = SimilarityIndex(reference_texts, reference_embeddings)

    query = np.array([1.0, 0.0])
    result = index.query(query)

    assert result.most_similar_review == "great product"
    assert result.highest_score > 0.9


def test_similarity_index_empty_reference():
    index = SimilarityIndex([], np.empty((0, 2)))
    assert index.is_empty()

    result = index.query(np.array([1.0, 0.0]))
    assert result.highest_score == 0.0
    assert result.most_similar_review is None


def test_similarity_index_top_matches_length():
    reference_texts = ["a", "b", "c", "d"]
    reference_embeddings = np.eye(4)[:, :2]
    index = SimilarityIndex(reference_texts, reference_embeddings)

    result = index.query(np.array([1.0, 0.0]), top_k=2)
    assert len(result.top_matches) == 2
