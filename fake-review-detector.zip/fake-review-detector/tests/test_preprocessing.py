from src.preprocessing import (
    clean_for_display,
    preprocess_for_modeling,
    remove_html,
    remove_urls,
)


def test_remove_html_strips_tags():
    text = "<p>Great product</p>"
    assert remove_html(text) == " Great product "


def test_remove_urls_strips_links():
    text = "Check this out https://example.com/product now"
    result = remove_urls(text)
    assert "https://example.com" not in result


def test_clean_for_display_normalizes_whitespace():
    text = "This   has     extra   spaces"
    assert clean_for_display(text) == "This has extra spaces"


def test_preprocess_for_modeling_lowercases_and_removes_stopwords():
    text = "This Product Is Absolutely The Best"
    result = preprocess_for_modeling(text)
    assert result == result.lower()
    assert "the" not in result.split()


def test_preprocess_for_modeling_handles_empty_string():
    assert preprocess_for_modeling("") == ""
