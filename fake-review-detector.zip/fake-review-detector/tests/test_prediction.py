import pytest

from src.predict import PredictionError, predict_review


def test_predict_review_empty_input_raises():
    with pytest.raises(PredictionError):
        predict_review("")


def test_predict_review_whitespace_input_raises():
    with pytest.raises(PredictionError):
        predict_review("     ")


def test_predict_review_returns_expected_keys():
    result = predict_review("The package arrived on time and works as described.")
    expected_keys = {
        "prediction",
        "label",
        "fake_probability",
        "genuine_probability",
        "sentiment",
        "review_statistics",
        "similarity_score",
        "most_similar_review",
        "suspicious_indicators",
        "important_features",
        "is_demo_model",
    }
    assert expected_keys.issubset(result.keys())


def test_predict_review_probabilities_sum_to_one():
    result = predict_review("A perfectly ordinary review about a product.")
    total = result["fake_probability"] + result["genuine_probability"]
    assert abs(total - 1.0) < 1e-6


def test_predict_review_prediction_matches_label():
    result = predict_review("Absolutely the best product ever, everyone must buy it now!!!")
    if result["label"] == 1:
        assert result["prediction"] == "Likely Fake"
    else:
        assert result["prediction"] == "Likely Genuine"
