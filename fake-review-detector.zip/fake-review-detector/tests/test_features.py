from src.feature_engineering import extract_features
from src.sentiment import analyze_sentiment, sentiment_label


def test_extract_features_basic_counts():
    text = "This is a great product. I really like it!"
    features = extract_features(text)
    assert features["word_count"] > 0
    assert features["sentence_count"] >= 1
    assert features["exclamation_count"] == 1


def test_extract_features_detects_uppercase():
    text = "THIS IS AMAZING"
    features = extract_features(text)
    assert features["uppercase_ratio"] > 0.5


def test_extract_features_empty_text():
    features = extract_features("")
    assert features["word_count"] == 0
    assert features["char_count"] == 0


def test_analyze_sentiment_positive_text():
    result = analyze_sentiment("This is a wonderful and amazing product")
    assert result["polarity"] > 0


def test_sentiment_label_classification():
    assert sentiment_label(0.5) == "Positive"
    assert sentiment_label(-0.5) == "Negative"
    assert sentiment_label(0.0) == "Neutral"
