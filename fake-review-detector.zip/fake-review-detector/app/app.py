"""Streamlit application for the Fake Review Detection & Review Intelligence System."""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import streamlit as st

from app.components.analyzer import render_batch_analysis_page, render_review_analyzer_page
from app.components.dashboard import render_dashboard_page, render_model_information_page
from app.components.ui import inject_base_styles

PAGES = ("Home", "Review Analyzer", "Model Information", "Batch Analysis", "Dashboard")


def render_home_page() -> None:
    st.title("Fake Review Detection & Review Intelligence System")
    st.write(
        "A machine learning and NLP system for assessing whether an online "
        "review resembles patterns typically associated with fake or genuine "
        "reviews."
    )

    st.subheader("System Purpose")
    st.write(
        "The system combines text preprocessing, TF-IDF features, sentence "
        "embeddings, statistical and linguistic features, sentiment analysis, "
        "and review similarity to produce a probability estimate rather than "
        "an absolute judgment."
    )

    st.subheader("Key Capabilities")
    capabilities = [
        "Single review analysis with fake probability and supporting evidence",
        "Batch analysis of many reviews from an uploaded CSV file",
        "Model comparison across several machine learning algorithms",
        "Similarity detection against a reference set of reviews",
        "Rule-based suspicious pattern indicators",
        "Feature-level explanations for individual predictions",
    ]
    for item in capabilities:
        st.markdown(f"- {item}")

    st.info(
        "Predictions describe how closely a review resembles patterns learned "
        "from training data. They are not a definitive judgment of authenticity."
    )


def main() -> None:
    st.set_page_config(
        page_title="Fake Review Detection System",
        layout="wide",
    )
    inject_base_styles()

    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", PAGES, label_visibility="collapsed")

    if page == "Home":
        render_home_page()
    elif page == "Review Analyzer":
        render_review_analyzer_page()
    elif page == "Model Information":
        render_model_information_page()
    elif page == "Batch Analysis":
        render_batch_analysis_page()
    elif page == "Dashboard":
        render_dashboard_page()


if __name__ == "__main__":
    main()
