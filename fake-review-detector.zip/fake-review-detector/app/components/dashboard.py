"""Model Information and Dashboard pages."""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from app.components.ui import render_demo_dataset_warning
from src.config import MODEL_METADATA_PATH
from src.evaluate import format_metrics_table


def _load_metadata() -> dict | None:
    if not MODEL_METADATA_PATH.exists():
        return None
    import json

    return json.loads(MODEL_METADATA_PATH.read_text())


def render_model_information_page() -> None:
    st.header("Model Information")

    metadata = _load_metadata()
    if metadata is None:
        st.info("No trained model found yet. Run 'python scripts/train_model.py' to train one.")
        return

    render_demo_dataset_warning(metadata.get("is_demo_dataset", False))

    col1, col2, col3 = st.columns(3)
    col1.metric("Selected Model", metadata["best_model"])
    col2.metric("Dataset Size", metadata["dataset_size"])
    col3.metric("Feature Types", " + ".join(metadata["feature_set"]))

    st.subheader("Class Distribution")
    class_distribution = metadata["class_distribution"]
    label_map = {"0": "Genuine", "1": "Fake"}
    dist_df = pd.DataFrame(
        {
            "class": [label_map.get(k, k) for k in class_distribution.keys()],
            "count": list(class_distribution.values()),
        }
    )
    st.dataframe(dist_df, hide_index=True, use_container_width=True)

    st.subheader("Model Comparison")
    rows = format_metrics_table(metadata["results"])
    comparison_df = pd.DataFrame(rows)
    st.dataframe(comparison_df, hide_index=True, use_container_width=True)

    st.caption(
        "The selected model is chosen automatically using F1-score on a held-out "
        "test set that was never used to fit the vectorizer or the classifier."
    )


def render_dashboard_page() -> None:
    st.header("Dashboard")

    metadata = _load_metadata()
    if metadata is None:
        st.info("No trained model found yet. Run 'python scripts/train_model.py' to train one.")
        return

    render_demo_dataset_warning(metadata.get("is_demo_dataset", False))

    st.subheader("Training Data: Fake vs Genuine")
    label_map = {"0": "Genuine", "1": "Fake"}
    class_distribution = metadata["class_distribution"]
    dist_df = pd.DataFrame(
        {
            "class": [label_map.get(k, k) for k in class_distribution.keys()],
            "count": list(class_distribution.values()),
        }
    )
    fig = px.bar(dist_df, x="class", y="count", color="class", title="Class Distribution")
    st.plotly_chart(fig, use_container_width=True)

    if "batch_results" in st.session_state:
        st.subheader("Batch Analysis Results")
        results_df = st.session_state["batch_results"].dropna()

        if not results_df.empty:
            pred_counts = results_df["prediction"].value_counts().reset_index()
            pred_counts.columns = ["prediction", "count"]
            fig_pred = px.bar(
                pred_counts, x="prediction", y="count", color="prediction",
                title="Prediction Distribution",
            )
            st.plotly_chart(fig_pred, use_container_width=True)

            sentiment_counts = results_df["sentiment"].value_counts().reset_index()
            sentiment_counts.columns = ["sentiment", "count"]
            fig_sentiment = px.pie(
                sentiment_counts, names="sentiment", values="count",
                title="Sentiment Distribution",
            )
            st.plotly_chart(fig_sentiment, use_container_width=True)

            fig_conf = px.histogram(
                results_df, x="fake_probability", nbins=20,
                title="Fake Probability Distribution",
            )
            st.plotly_chart(fig_conf, use_container_width=True)
    else:
        st.caption("Run a batch analysis to see prediction, sentiment and confidence distributions here.")
