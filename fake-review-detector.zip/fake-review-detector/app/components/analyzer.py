"""Review Analyzer and Batch Analysis pages."""

from __future__ import annotations

import io

import pandas as pd
import streamlit as st

from app.components.ui import render_demo_dataset_warning, render_indicator_pills, render_verdict
from src.config import SETTINGS
from src.data_loader import DatasetError, detect_columns
from src.predict import ModelNotTrainedError, PredictionError, predict_review

MAX_UPLOAD_ROWS = SETTINGS.app.max_upload_rows
MAX_UPLOAD_SIZE_MB = SETTINGS.app.max_upload_size_mb


def render_review_analyzer_page() -> None:
    st.header("Review Analyzer")
    st.write("Paste a review below to check whether it resembles genuine or fake review patterns.")

    review_text = st.text_area(
        "Enter your review here...",
        height=160,
        placeholder="Enter your review here...",
        label_visibility="collapsed",
    )

    analyze_clicked = st.button("Analyze Review", type="primary")

    if not analyze_clicked:
        return

    if not review_text or not review_text.strip():
        st.error("Please enter a review before running the analysis.")
        return

    try:
        result = predict_review(review_text)
    except ModelNotTrainedError:
        st.error(
            "No trained model was found. Run 'python scripts/train_model.py' "
            "from the project root before using the analyzer."
        )
        return
    except PredictionError as exc:
        st.error(f"Could not analyze this review: {exc}")
        return

    render_demo_dataset_warning(result.get("is_demo_model", False))
    _render_prediction_result(result)


def _render_prediction_result(result: dict) -> None:
    col_left, col_right = st.columns([2, 1])

    with col_left:
        render_verdict(result["prediction"])
        st.caption("This prediction reflects patterns learned from training data, not certainty.")

    with col_right:
        st.metric("Fake Probability", f"{result['fake_probability'] * 100:.1f}%")
        st.metric("Genuine Probability", f"{result['genuine_probability'] * 100:.1f}%")

    st.subheader("Sentiment")
    sentiment = result["sentiment"]
    sentiment_cols = st.columns(3)
    sentiment_cols[0].metric("Polarity", f"{sentiment['polarity']:.2f}")
    sentiment_cols[1].metric("Subjectivity", f"{sentiment['subjectivity']:.2f}")
    sentiment_cols[2].metric("Tone", sentiment["label"])

    st.subheader("Review Statistics")
    stats = result["review_statistics"]
    stat_cols = st.columns(4)
    stat_cols[0].metric("Words", stats["word_count"])
    stat_cols[1].metric("Sentences", stats["sentence_count"])
    stat_cols[2].metric("Exclamation Marks", stats["exclamation_count"])
    stat_cols[3].metric("Uppercase Ratio", f"{stats['uppercase_ratio'] * 100:.0f}%")

    with st.expander("Full statistics"):
        st.json(stats)

    st.subheader("Similarity with Existing Reviews")
    if result["most_similar_review"]:
        st.metric("Highest Similarity Score", f"{result['similarity_score'] * 100:.0f}%")
        st.caption("Most similar reference review:")
        st.write(result["most_similar_review"])
        st.caption("High similarity is supporting evidence, not proof of a fake review.")
    else:
        st.write("No reference reviews were available for similarity comparison.")

    st.subheader("Suspicious Indicators")
    render_indicator_pills(result["suspicious_indicators"])
    st.caption("These are indicators, not definitive evidence of deception.")

    if result["important_features"]:
        st.subheader("Important Features")
        features_df = pd.DataFrame(result["important_features"])
        st.dataframe(features_df, use_container_width=True, hide_index=True)
        st.caption("Terms that most influenced this specific prediction.")


def render_batch_analysis_page() -> None:
    st.header("Batch Analysis")
    st.write("Upload a CSV file containing a review column to analyze many reviews at once.")

    uploaded_file = st.file_uploader("Upload CSV", type=["csv"])

    if uploaded_file is None:
        return

    size_mb = uploaded_file.size / (1024 * 1024)
    if size_mb > MAX_UPLOAD_SIZE_MB:
        st.error(f"File is too large ({size_mb:.1f} MB). Maximum allowed size is {MAX_UPLOAD_SIZE_MB} MB.")
        return

    try:
        raw_bytes = uploaded_file.read()
        df = pd.read_csv(io.BytesIO(raw_bytes))
    except Exception:
        st.error("Could not parse the uploaded file. Please upload a valid CSV file.")
        return

    if df.empty:
        st.error("The uploaded file is empty.")
        return

    try:
        review_col, _ = detect_columns(df)
    except DatasetError as exc:
        st.error(str(exc))
        return

    if len(df) > MAX_UPLOAD_ROWS:
        st.warning(f"File has {len(df)} rows; only the first {MAX_UPLOAD_ROWS} will be analyzed.")
        df = df.head(MAX_UPLOAD_ROWS)

    if st.button("Run Batch Analysis", type="primary"):
        results = []
        progress_bar = st.progress(0.0)
        total = len(df)

        for i, review_text in enumerate(df[review_col].astype(str)):
            try:
                prediction = predict_review(review_text)
                results.append(
                    {
                        "review": review_text,
                        "prediction": prediction["prediction"],
                        "fake_probability": prediction["fake_probability"],
                        "genuine_probability": prediction["genuine_probability"],
                        "sentiment": prediction["sentiment"]["label"],
                        "similarity_score": prediction["similarity_score"],
                    }
                )
            except ModelNotTrainedError:
                st.error(
                    "No trained model was found. Run 'python scripts/train_model.py' "
                    "from the project root before using batch analysis."
                )
                return
            except PredictionError:
                results.append(
                    {
                        "review": review_text,
                        "prediction": "Error",
                        "fake_probability": None,
                        "genuine_probability": None,
                        "sentiment": None,
                        "similarity_score": None,
                    }
                )
            progress_bar.progress((i + 1) / total)

        results_df = pd.DataFrame(results)
        st.session_state["batch_results"] = results_df

    if "batch_results" in st.session_state:
        results_df = st.session_state["batch_results"]
        st.subheader("Results")
        st.dataframe(results_df, use_container_width=True, hide_index=True)

        csv_bytes = results_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            "Download Results CSV",
            data=csv_bytes,
            file_name="batch_analysis_results.csv",
            mime="text/csv",
        )
