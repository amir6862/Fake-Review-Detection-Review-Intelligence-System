"""Shared Streamlit styling and small presentational helpers."""

from __future__ import annotations

import streamlit as st

CUSTOM_CSS = """
<style>
    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1100px;
    }
    h1, h2, h3 {
        font-weight: 600;
        letter-spacing: -0.01em;
    }
    div[data-testid="stMetric"] {
        background-color: #f8f9fb;
        border: 1px solid #e6e8eb;
        border-radius: 10px;
        padding: 14px 16px;
    }
    .review-card {
        background-color: #f8f9fb;
        border: 1px solid #e6e8eb;
        border-radius: 10px;
        padding: 18px 20px;
        margin-bottom: 14px;
    }
    .indicator-pill {
        display: inline-block;
        background-color: #fdecec;
        color: #9b2c2c;
        border: 1px solid #f3c6c6;
        border-radius: 16px;
        padding: 4px 12px;
        margin: 3px 6px 3px 0;
        font-size: 0.85rem;
    }
    .verdict-fake {
        color: #9b2c2c;
        font-weight: 700;
        font-size: 1.4rem;
    }
    .verdict-genuine {
        color: #1a6b3c;
        font-weight: 700;
        font-size: 1.4rem;
    }
    .caption-note {
        color: #6b7280;
        font-size: 0.85rem;
    }
</style>
"""


def inject_base_styles() -> None:
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def render_card(title: str, body_markdown: str) -> None:
    st.markdown(
        f'<div class="review-card"><strong>{title}</strong><br>{body_markdown}</div>',
        unsafe_allow_html=True,
    )


def render_indicator_pills(indicators: list[str]) -> None:
    if not indicators:
        st.write("No suspicious indicators detected.")
        return
    pills = "".join(f'<span class="indicator-pill">{item}</span>' for item in indicators)
    st.markdown(pills, unsafe_allow_html=True)


def render_verdict(prediction: str) -> None:
    css_class = "verdict-fake" if "Fake" in prediction else "verdict-genuine"
    st.markdown(f'<div class="{css_class}">{prediction}</div>', unsafe_allow_html=True)


def render_demo_dataset_warning(is_demo: bool) -> None:
    if is_demo:
        st.warning(
            "This model was trained on a small bundled demo dataset for "
            "demonstration purposes. Its predictions do not reflect "
            "real-world accuracy. Replace data/raw/reviews.csv with a real "
            "labeled dataset and retrain for meaningful results.",
            icon=None,
        )
