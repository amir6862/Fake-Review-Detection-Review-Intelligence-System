"""Command line entry point for inspecting the currently trained model.

Usage:
    python scripts/evaluate_model.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.config import MODEL_METADATA_PATH  # noqa: E402
from src.evaluate import format_metrics_table  # noqa: E402


def main() -> None:
    if not MODEL_METADATA_PATH.exists():
        print("No trained model metadata found. Run scripts/train_model.py first.")
        return

    metadata = json.loads(MODEL_METADATA_PATH.read_text())

    print(f"Selected model: {metadata['best_model']}")
    print(f"Feature set: {' + '.join(metadata['feature_set'])}")
    print(f"Dataset size: {metadata['dataset_size']}")
    print(f"Class distribution: {metadata['class_distribution']}")
    if metadata.get("is_demo_dataset"):
        print("Warning: model was trained on the small bundled demo dataset. "
              "Metrics do not reflect real-world performance.")

    print("\nModel comparison:")
    for row in format_metrics_table(metadata["results"]):
        print(row)


if __name__ == "__main__":
    main()
