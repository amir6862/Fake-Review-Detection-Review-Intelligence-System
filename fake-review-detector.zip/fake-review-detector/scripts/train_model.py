"""Command line entry point for training the fake review classifier.

Usage:
    python scripts/train_model.py
    python scripts/train_model.py --dataset data/raw/reviews.csv
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.evaluate import format_metrics_table  # noqa: E402
from src.train import train_and_evaluate  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the fake review detection model.")
    parser.add_argument(
        "--dataset",
        type=str,
        default=None,
        help="Path to a CSV dataset with review and label columns. "
        "Defaults to the bundled demo dataset if not provided.",
    )
    args = parser.parse_args()

    dataset_path = Path(args.dataset) if args.dataset else None

    print("Training fake review detection models...")
    output = train_and_evaluate(dataset_path)

    print("\nModel comparison:")
    header = f"{'Model':<26}{'Features':<22}{'Acc':<8}{'Prec':<8}{'Rec':<8}{'F1':<8}{'ROC-AUC':<10}{'CV-F1':<8}"
    print(header)
    print("-" * len(header))
    for row in format_metrics_table(output["results"]):
        roc_auc = row.get("roc_auc")
        cv_f1 = row.get("cv_f1_mean")
        print(
            f"{row['model']:<26}{row['feature_set']:<22}"
            f"{row['accuracy']:<8}{row['precision']:<8}{row['recall']:<8}{row['f1']:<8}"
            f"{(roc_auc if roc_auc is not None else '-'): <10}"
            f"{(cv_f1 if cv_f1 is not None else '-'): <8}"
        )

    print(f"\nSelected model: {output['best_model']}")
    print(f"Feature set: {' + '.join(output['feature_set'])}")
    print("\nArtifacts saved to the models/ directory.")


if __name__ == "__main__":
    main()
