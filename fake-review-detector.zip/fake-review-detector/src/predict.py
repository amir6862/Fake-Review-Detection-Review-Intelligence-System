"""Single reusable prediction pipeline used by both the app and batch jobs."""

from __future__ import annotations

import functools
import json
from dataclasses import dataclass, field

import joblib
import numpy as np
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer

from src.config import (
    CLASSIFIER_PATH,
    FEATURE_CONFIG_PATH,
    MODEL_METADATA_PATH,
    SETTINGS,
    SIMILARITY_REFERENCE_PATH,
    VECTORIZER_PATH,
    FEATURE_SCALER_PATH,
)
from src.embeddings import EmbeddingModelError, encode_single
from src.explainability import detect_suspicious_indicators, extract_important_features
from src.feature_engineering import extract_features
from src.preprocessing import preprocess_for_modeling
from src.sentiment import analyze_sentiment, sentiment_label
from src.similarity import SimilarityIndex


class PredictionError(Exception):
    """Raised when a review cannot be scored, e.g. missing model artifacts."""


class ModelNotTrainedError(PredictionError):
    """Raised when the trained model artifacts are not present on disk."""


@dataclass
class PredictionResult:
    prediction: str
    label: int
    fake_probability: float
    genuine_probability: float
    sentiment: dict
    review_statistics: dict
    similarity_score: float
    most_similar_review: str | None
    suspicious_indicators: list
    important_features: list
    is_demo_model: bool = field(default=False)

    def to_dict(self) -> dict:
        return {
            "prediction": self.prediction,
            "label": self.label,
            "fake_probability": self.fake_probability,
            "genuine_probability": self.genuine_probability,
            "sentiment": self.sentiment,
            "review_statistics": self.review_statistics,
            "similarity_score": self.similarity_score,
            "most_similar_review": self.most_similar_review,
            "suspicious_indicators": self.suspicious_indicators,
            "important_features": self.important_features,
            "is_demo_model": self.is_demo_model,
        }


@functools.lru_cache(maxsize=1)
def _load_artifacts():
    if not CLASSIFIER_PATH.exists() or not VECTORIZER_PATH.exists():
        raise ModelNotTrainedError(
            "No trained model was found. Run 'python scripts/train_model.py' first."
        )

    classifier = joblib.load(CLASSIFIER_PATH)
    vectorizer: TfidfVectorizer = joblib.load(VECTORIZER_PATH)
    scaler = joblib.load(FEATURE_SCALER_PATH) if FEATURE_SCALER_PATH.exists() else None

    feature_config = {}
    if FEATURE_CONFIG_PATH.exists():
        feature_config = json.loads(FEATURE_CONFIG_PATH.read_text())

    metadata = {}
    if MODEL_METADATA_PATH.exists():
        metadata = json.loads(MODEL_METADATA_PATH.read_text())

    similarity_index = None
    if SIMILARITY_REFERENCE_PATH.exists():
        data = joblib.load(SIMILARITY_REFERENCE_PATH)
        similarity_index = SimilarityIndex.from_dict(data)

    return classifier, vectorizer, scaler, feature_config, metadata, similarity_index


def clear_artifact_cache() -> None:
    """Force artifacts to be reloaded, used after retraining."""
    _load_artifacts.cache_clear()


def _predict_fake_probability(estimator, X) -> float:
    if hasattr(estimator, "predict_proba"):
        proba = estimator.predict_proba(X)[0]
        classes = list(estimator.classes_)
        fake_index = classes.index(1) if 1 in classes else -1
        return float(proba[fake_index])
    if hasattr(estimator, "decision_function"):
        score = estimator.decision_function(X)[0]
        return float(1.0 / (1.0 + np.exp(-score)))
    return float(estimator.predict(X)[0])


def predict_review(review_text: str) -> dict:
    """Run the full inference pipeline for a single review.

    Returns a structured dictionary with the prediction, probabilities,
    sentiment, statistics, similarity information and explanations.
    """
    if not review_text or not review_text.strip():
        raise PredictionError("Review text cannot be empty.")

    classifier, vectorizer, scaler, feature_config, metadata, similarity_index = _load_artifacts()
    feature_set = feature_config.get("feature_set", ["tfidf"])

    processed_text = preprocess_for_modeling(review_text)
    features = extract_features(review_text)
    sentiment = analyze_sentiment(review_text)
    sentiment["label"] = sentiment_label(sentiment["polarity"])

    tfidf_vector = vectorizer.transform([processed_text])

    engineered_names = feature_config.get("engineered_feature_names", [])
    engineered_values = None
    if engineered_names and scaler is not None:
        raw_values = []
        for name in engineered_names:
            if name in features:
                raw_values.append(features[name])
            elif name in sentiment:
                raw_values.append(sentiment[name])
            else:
                raw_values.append(0.0)
        engineered_values = scaler.transform(np.array([raw_values], dtype=float))

    embedding_vector = None
    if "embeddings" in feature_set:
        try:
            embedding_vector = encode_single(review_text).reshape(1, -1)
        except EmbeddingModelError as exc:
            raise PredictionError(str(exc)) from exc

    parts = []
    if "tfidf" in feature_set:
        parts.append(tfidf_vector)
    if "engineered" in feature_set and engineered_values is not None:
        parts.append(sparse.csr_matrix(engineered_values))
    if "embeddings" in feature_set and embedding_vector is not None:
        parts.append(sparse.csr_matrix(embedding_vector))

    if not parts:
        raise PredictionError("No usable features were available for this model.")

    X = parts[0] if len(parts) == 1 else sparse.hstack(parts).tocsr()

    predicted_label = int(classifier.predict(X)[0])
    fake_probability = _predict_fake_probability(classifier, X)
    genuine_probability = 1.0 - fake_probability

    similarity_score = 0.0
    most_similar_review = None
    if similarity_index is not None and not similarity_index.is_empty():
        try:
            query_embedding = embedding_vector.ravel() if embedding_vector is not None else encode_single(review_text)
            similarity_result = similarity_index.query(query_embedding)
            similarity_score = similarity_result.highest_score
            most_similar_review = similarity_result.most_similar_review
        except EmbeddingModelError:
            similarity_score = 0.0

    suspicious_indicators = detect_suspicious_indicators(
        review_text,
        features,
        sentiment,
        similarity_score,
        SETTINGS.app.similarity_threshold,
    )

    important_features = extract_important_features(
        classifier, vectorizer, tfidf_vector, feature_set
    )

    result = PredictionResult(
        prediction="Likely Fake" if predicted_label == 1 else "Likely Genuine",
        label=predicted_label,
        fake_probability=round(fake_probability, 4),
        genuine_probability=round(genuine_probability, 4),
        sentiment=sentiment,
        review_statistics=features,
        similarity_score=similarity_score,
        most_similar_review=most_similar_review,
        suspicious_indicators=suspicious_indicators,
        important_features=important_features,
        is_demo_model=metadata.get("is_demo_dataset", False),
    )
    return result.to_dict()


def get_model_metadata() -> dict:
    _, _, _, _, metadata, _ = _load_artifacts()
    return metadata
