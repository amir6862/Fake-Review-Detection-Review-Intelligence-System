"""Central configuration for the fake review detection system.

All paths are resolved relative to the project root so the project runs
the same way on Windows and Linux.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_DIR = PROJECT_ROOT / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
SAMPLE_DATA_DIR = DATA_DIR / "sample"

MODELS_DIR = PROJECT_ROOT / "models"
CLASSIFIER_DIR = MODELS_DIR / "classifier"
VECTORIZER_DIR = MODELS_DIR / "vectorizer"
EMBEDDINGS_DIR = MODELS_DIR / "embeddings"

SAMPLE_DATASET_PATH = SAMPLE_DATA_DIR / "sample_reviews.csv"
DEFAULT_DATASET_PATH = RAW_DATA_DIR / "reviews.csv"

CLASSIFIER_PATH = CLASSIFIER_DIR / "classifier.pkl"
VECTORIZER_PATH = VECTORIZER_DIR / "tfidf_vectorizer.pkl"
FEATURE_SCALER_PATH = VECTORIZER_DIR / "feature_scaler.pkl"
FEATURE_CONFIG_PATH = CLASSIFIER_DIR / "feature_config.json"
MODEL_METADATA_PATH = CLASSIFIER_DIR / "model_metadata.json"
SIMILARITY_REFERENCE_PATH = EMBEDDINGS_DIR / "similarity_reference.pkl"

# Candidate columns that are auto-detected in a user supplied dataset.
REVIEW_COLUMN_CANDIDATES = ("review", "review_text", "text", "content", "comment")
LABEL_COLUMN_CANDIDATES = ("label", "is_fake", "fake", "target", "class")

GENUINE_LABEL = 0
FAKE_LABEL = 1
LABEL_NAMES = {GENUINE_LABEL: "Genuine", FAKE_LABEL: "Fake"}


@dataclass
class TfidfConfig:
    max_features: int = 5000
    ngram_range: tuple = (1, 2)
    min_df: int = 2
    max_df: float = 0.9
    sublinear_tf: bool = True


@dataclass
class EmbeddingConfig:
    model_name: str = "all-MiniLM-L6-v2"
    batch_size: int = 32
    normalize_embeddings: bool = True


@dataclass
class TrainingConfig:
    random_seed: int = 42
    test_size: float = 0.2
    cv_folds: int = 5
    primary_metric: str = "f1"


@dataclass
class AppConfig:
    similarity_threshold: float = 0.75
    max_upload_rows: int = 5000
    max_upload_size_mb: int = 10


@dataclass
class Settings:
    tfidf: TfidfConfig = field(default_factory=TfidfConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    app: AppConfig = field(default_factory=AppConfig)


SETTINGS = Settings()


def ensure_directories() -> None:
    """Create all project directories that the pipeline writes to."""
    for directory in (
        RAW_DATA_DIR,
        PROCESSED_DATA_DIR,
        SAMPLE_DATA_DIR,
        CLASSIFIER_DIR,
        VECTORIZER_DIR,
        EMBEDDINGS_DIR,
    ):
        directory.mkdir(parents=True, exist_ok=True)
