"""Explainability helpers: rule-based indicators and model feature attribution."""

from __future__ import annotations

import re

import numpy as np

_PROMOTIONAL_PHRASES = (
    "best product",
    "best purchase",
    "buy now",
    "buy it now",
    "must buy",
    "you will not regret",
    "you won't regret",
    "life changing",
    "changed my life",
    "everyone should",
    "everyone must",
    "highly recommend",
    "10/10",
    "five stars",
    "amazing amazing",
)

_REPEATED_PHRASE_PATTERN = re.compile(r"\b(\w+)\b(?:\s+\1\b)+", flags=re.IGNORECASE)


def detect_suspicious_indicators(
    raw_text: str,
    features: dict,
    sentiment: dict,
    similarity_score: float,
    similarity_threshold: float,
) -> list[str]:
    """Return human-readable indicators describing suspicious characteristics.

    These are presented as supporting signals, never as proof of deception.
    """
    indicators: list[str] = []
    lower_text = raw_text.lower()

    if features["exclamation_count"] >= 3:
        indicators.append("Excessive exclamation marks")

    if features["char_count"] > 0 and features["uppercase_ratio"] > 0.3:
        indicators.append("Excessive capitalization")

    if features["repeated_word_ratio"] > 0.25:
        indicators.append("High proportion of repeated words")

    if features["word_count"] < 6:
        indicators.append("Unusually short review")
    elif features["word_count"] > 200:
        indicators.append("Unusually long review")

    if any(phrase in lower_text for phrase in _PROMOTIONAL_PHRASES):
        indicators.append("Strong promotional language")

    if _REPEATED_PHRASE_PATTERN.search(raw_text):
        indicators.append("Repetitive phrasing")

    if abs(sentiment["polarity"]) > 0.8:
        indicators.append("Unusually extreme sentiment")

    if features["punctuation_count"] > max(features["word_count"] * 0.3, 5):
        indicators.append("Excessive punctuation")

    if similarity_score >= similarity_threshold:
        indicators.append("High similarity with existing reviews")

    return indicators


def extract_important_features(
    estimator,
    tfidf_vectorizer,
    tfidf_vector,
    feature_set: list[str],
    top_n: int = 8,
) -> list[dict]:
    """Extract the TF-IDF terms that most influenced a linear model's decision.

    Returns an empty list for non-linear models or when TF-IDF is not part
    of the feature set, since attribution is only meaningful for models with
    interpretable per-feature coefficients.
    """
    if "tfidf" not in feature_set:
        return []

    coefficients = _get_linear_coefficients(estimator)
    if coefficients is None:
        return []

    vocabulary_size = len(tfidf_vectorizer.get_feature_names_out())
    tfidf_coefficients = coefficients[:vocabulary_size]

    vector_array = tfidf_vector.toarray().ravel()[:vocabulary_size]
    nonzero_indices = np.nonzero(vector_array)[0]
    if nonzero_indices.size == 0:
        return []

    contributions = vector_array[nonzero_indices] * tfidf_coefficients[nonzero_indices]
    feature_names = tfidf_vectorizer.get_feature_names_out()

    order = np.argsort(np.abs(contributions))[::-1][:top_n]

    results = []
    for i in order:
        idx = nonzero_indices[i]
        contribution = float(contributions[i])
        if abs(contribution) < 1e-6:
            continue
        results.append(
            {
                "term": feature_names[idx],
                "contribution": round(contribution, 4),
                "direction": "fake" if contribution > 0 else "genuine",
            }
        )
    return results


def _get_linear_coefficients(estimator):
    if hasattr(estimator, "coef_"):
        coef = estimator.coef_
        return coef[0] if coef.ndim == 2 else coef
    return None
