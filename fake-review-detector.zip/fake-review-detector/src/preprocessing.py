"""Reusable text preprocessing shared between training and prediction."""

from __future__ import annotations

import re

import nltk

_REQUIRED_NLTK_RESOURCES = {
    "tokenizers/punkt": "punkt",
    "tokenizers/punkt_tab": "punkt_tab",
    "corpora/stopwords": "stopwords",
    "corpora/wordnet": "wordnet",
}


def _ensure_nltk_resources() -> None:
    for resource_path, download_name in _REQUIRED_NLTK_RESOURCES.items():
        try:
            nltk.data.find(resource_path)
        except LookupError:
            try:
                nltk.download(download_name, quiet=True)
            except Exception:  # noqa: BLE001
                pass


_ensure_nltk_resources()

from nltk.corpus import stopwords  # noqa: E402
from nltk.stem import WordNetLemmatizer  # noqa: E402
from nltk.tokenize import word_tokenize  # noqa: E402

try:
    STOPWORDS = set(stopwords.words("english"))
except LookupError:
    STOPWORDS = set()

_LEMMATIZER = WordNetLemmatizer()

_HTML_TAG_PATTERN = re.compile(r"<[^>]+>")
_URL_PATTERN = re.compile(r"https?://\S+|www\.\S+")
_MULTI_SPACE_PATTERN = re.compile(r"\s+")
_NON_ALPHA_PATTERN = re.compile(r"[^a-zA-Z\s]")


def remove_html(text: str) -> str:
    return _HTML_TAG_PATTERN.sub(" ", text)


def remove_urls(text: str) -> str:
    return _URL_PATTERN.sub(" ", text)


def normalize_whitespace(text: str) -> str:
    return _MULTI_SPACE_PATTERN.sub(" ", text).strip()


def tokenize(text: str) -> list[str]:
    try:
        return word_tokenize(text)
    except LookupError:
        return text.split()


def remove_stopwords(tokens: list[str]) -> list[str]:
    return [token for token in tokens if token.lower() not in STOPWORDS]


def lemmatize(tokens: list[str]) -> list[str]:
    try:
        return [_LEMMATIZER.lemmatize(token) for token in tokens]
    except LookupError:
        return tokens


def clean_for_display(text: str) -> str:
    """Light cleaning that preserves punctuation, used before feature extraction."""
    text = remove_html(text)
    text = remove_urls(text)
    text = normalize_whitespace(text)
    return text


def preprocess_for_modeling(
    text: str,
    lowercase: bool = True,
    strip_punctuation: bool = True,
    remove_stop: bool = True,
    apply_lemmatization: bool = True,
) -> str:
    """Full preprocessing pipeline that produces text suitable for TF-IDF.

    This is used identically during training and prediction so that the
    fitted vectorizer always sees text prepared the same way.
    """
    text = clean_for_display(text)

    if lowercase:
        text = text.lower()

    if strip_punctuation:
        text = _NON_ALPHA_PATTERN.sub(" ", text)

    text = normalize_whitespace(text)

    tokens = tokenize(text)

    if remove_stop:
        tokens = remove_stopwords(tokens)

    if apply_lemmatization:
        tokens = lemmatize(tokens)

    return " ".join(tokens)


def preprocess_series(texts, **kwargs) -> list[str]:
    """Apply ``preprocess_for_modeling`` to an iterable of raw texts."""
    return [preprocess_for_modeling(str(text), **kwargs) for text in texts]
