"""Evaluation metrics and reporting utilities."""

from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray, y_proba: np.ndarray) -> dict:
    """Compute the standard classification metrics for one model."""
    metrics = {
        "accuracy": round(float(accuracy_score(y_true, y_pred)), 4),
        "precision": round(float(precision_score(y_true, y_pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_true, y_pred, zero_division=0)), 4),
        "f1": round(float(f1_score(y_true, y_pred, zero_division=0)), 4),
    }

    unique_labels = np.unique(y_true)
    if len(unique_labels) > 1:
        try:
            metrics["roc_auc"] = round(float(roc_auc_score(y_true, y_proba)), 4)
        except ValueError:
            metrics["roc_auc"] = None
    else:
        metrics["roc_auc"] = None

    return metrics


def full_report(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Return the confusion matrix and classification report as plain data."""
    cm = confusion_matrix(y_true, y_pred).tolist()
    report = classification_report(y_true, y_pred, zero_division=0, output_dict=True)
    return {"confusion_matrix": cm, "classification_report": report}


def format_metrics_table(results: dict) -> list[dict]:
    """Flatten the results dict produced by training into table rows."""
    rows = []
    for name, payload in results.items():
        row = {"model": name, "feature_set": " + ".join(payload["feature_set"])}
        row.update(payload["metrics"])
        row["cv_f1_mean"] = payload.get("cv_f1_mean")
        rows.append(row)
    rows.sort(key=lambda r: r.get("f1") or 0.0, reverse=True)
    return rows
