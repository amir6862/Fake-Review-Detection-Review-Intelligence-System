"""Sentiment feature extraction using TextBlob."""

from __future__ import annotations

import pandas as pd
from textblob import TextBlob

SENTIMENT_FEATURE_NAMES = ["polarity", "subjectivity"]


def analyze_sentiment(text: str) -> dict:
    """Return polarity in [-1, 1] and subjectivity in [0, 1] for a review."""
    if not text or not text.strip():
        return {"polarity": 0.0, "subjectivity": 0.0}

    blob = TextBlob(text)
    return {
        "polarity": round(float(blob.sentiment.polarity), 4),
        "subjectivity": round(float(blob.sentiment.subjectivity), 4),
    }


def sentiment_label(polarity: float) -> str:
    if polarity > 0.15:
        return "Positive"
    if polarity < -0.15:
        return "Negative"
    return "Neutral"


def analyze_sentiment_batch(texts: pd.Series) -> pd.DataFrame:
    records = [analyze_sentiment(text) for text in texts]
    return pd.DataFrame.from_records(records, columns=SENTIMENT_FEATURE_NAMES)
