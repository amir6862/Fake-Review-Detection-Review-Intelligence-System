"""Training pipeline: feature extraction, model comparison and persistence.

The train/test split happens before any preprocessing component is fit, and
statistical/sentiment features are scaled using a scaler fit on the training
split only, so no information from the held-out test set leaks into the
model.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import joblib
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC

from src.config import (
    CLASSIFIER_PATH,
    FEATURE_CONFIG_PATH,
    MODEL_METADATA_PATH,
    SETTINGS,
    SIMILARITY_REFERENCE_PATH,
    VECTORIZER_PATH,
    FEATURE_SCALER_PATH,
    ensure_directories,
)
from src.data_loader import load_and_clean
from src.embeddings import EmbeddingModelError, encode_texts
from src.evaluate import compute_metrics
from src.feature_engineering import FEATURE_NAMES, extract_features_batch
from src.preprocessing import preprocess_series
from src.sentiment import SENTIMENT_FEATURE_NAMES, analyze_sentiment_batch

try:
    import xgboost as xgb

    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

ENGINEERED_FEATURE_NAMES = FEATURE_NAMES + SENTIMENT_FEATURE_NAMES


def build_engineered_features(raw_texts: pd.Series) -> pd.DataFrame:
    stats = extract_features_batch(raw_texts)
    sentiment = analyze_sentiment_batch(raw_texts)
    return pd.concat([stats, sentiment], axis=1)


def _make_model_variants(seed: int) -> dict:
    variants = {
        "tfidf_logreg": {
            "features": ("tfidf",),
            "estimator": LogisticRegression(max_iter=1000, random_state=seed),
        },
        "tfidf_svm": {
            "features": ("tfidf",),
            "estimator": LinearSVC(random_state=seed),
        },
        "tfidf_naive_bayes": {
            "features": ("tfidf",),
            "estimator": MultinomialNB(),
        },
        "embeddings_logreg": {
            "features": ("embeddings",),
            "estimator": LogisticRegression(max_iter=1000, random_state=seed),
        },
        "engineered_random_forest": {
            "features": ("engineered",),
            "estimator": RandomForestClassifier(n_estimators=200, random_state=seed),
        },
        "combined_logreg": {
            "features": ("tfidf", "engineered"),
            "estimator": LogisticRegression(max_iter=1000, random_state=seed),
        },
    }
    if XGBOOST_AVAILABLE:
        variants["combined_xgboost"] = {
            "features": ("tfidf", "engineered"),
            "estimator": xgb.XGBClassifier(
                n_estimators=200,
                max_depth=4,
                learning_rate=0.1,
                random_state=seed,
                eval_metric="logloss",
            ),
        }
    return variants


def _assemble_matrix(feature_set, tfidf_matrix, engineered_scaled, embeddings):
    parts = []
    if "tfidf" in feature_set:
        parts.append(tfidf_matrix)
    if "engineered" in feature_set:
        parts.append(sparse.csr_matrix(engineered_scaled))
    if "embeddings" in feature_set:
        parts.append(sparse.csr_matrix(embeddings))
    if len(parts) == 1:
        return parts[0].tocsr() if sparse.issparse(parts[0]) else sparse.csr_matrix(parts[0])
    return sparse.hstack(parts).tocsr()


def _predict_fake_probability(estimator, X) -> np.ndarray:
    if hasattr(estimator, "predict_proba"):
        proba = estimator.predict_proba(X)
        classes = list(estimator.classes_)
        fake_index = classes.index(1) if 1 in classes else -1
        return proba[:, fake_index]
    if hasattr(estimator, "decision_function"):
        scores = estimator.decision_function(X)
        return 1.0 / (1.0 + np.exp(-scores))
    return estimator.predict(X).astype(float)


def _cross_validate_tfidf_only(texts_processed, y, estimator_factory, seed) -> Optional[float]:
    min_class_count = int(np.bincount(y).min())
    n_splits = min(SETTINGS.training.cv_folds, min_class_count)
    if n_splits < 2:
        return None

    pipeline = Pipeline(
        [
            (
                "tfidf",
                TfidfVectorizer(
                    max_features=SETTINGS.tfidf.max_features,
                    ngram_range=SETTINGS.tfidf.ngram_range,
                    min_df=1,
                    max_df=SETTINGS.tfidf.max_df,
                    sublinear_tf=SETTINGS.tfidf.sublinear_tf,
                ),
            ),
            ("clf", estimator_factory()),
        ]
    )
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    try:
        scores = cross_val_score(pipeline, texts_processed, y, cv=skf, scoring="f1")
        return round(float(scores.mean()), 4)
    except Exception:  # noqa: BLE001
        return None


def train_and_evaluate(dataset_path: Optional[Path] = None) -> dict:
    """Run the full training pipeline and persist the best model.

    Returns a dictionary with per-model metrics and the selected model name.
    """
    ensure_directories()

    df = load_and_clean(dataset_path)
    if "label" not in df.columns:
        raise ValueError("The dataset must include a label column to train a classifier.")
    if df["label"].nunique() < 2:
        raise ValueError("The dataset must contain both genuine (0) and fake (1) examples.")

    seed = SETTINGS.training.random_seed
    train_df, test_df = train_test_split(
        df,
        test_size=SETTINGS.training.test_size,
        random_state=seed,
        stratify=df["label"],
    )

    train_texts_raw = train_df["review"].tolist()
    test_texts_raw = test_df["review"].tolist()
    y_train = train_df["label"].to_numpy()
    y_test = test_df["label"].to_numpy()

    train_texts_processed = preprocess_series(train_texts_raw)
    test_texts_processed = preprocess_series(test_texts_raw)

    tfidf = TfidfVectorizer(
        max_features=SETTINGS.tfidf.max_features,
        ngram_range=SETTINGS.tfidf.ngram_range,
        min_df=min(SETTINGS.tfidf.min_df, max(1, len(train_texts_processed) // 10)),
        max_df=SETTINGS.tfidf.max_df,
        sublinear_tf=SETTINGS.tfidf.sublinear_tf,
    )
    tfidf_train = tfidf.fit_transform(train_texts_processed)
    tfidf_test = tfidf.transform(test_texts_processed)

    engineered_train = build_engineered_features(pd.Series(train_texts_raw))
    engineered_test = build_engineered_features(pd.Series(test_texts_raw))

    scaler = StandardScaler()
    engineered_train_scaled = scaler.fit_transform(engineered_train.to_numpy())
    engineered_test_scaled = scaler.transform(engineered_test.to_numpy())

    embeddings_available = True
    embeddings_train = embeddings_test = None
    try:
        embeddings_train = encode_texts(train_texts_raw)
        embeddings_test = encode_texts(test_texts_raw)
    except EmbeddingModelError:
        embeddings_available = False

    variants = _make_model_variants(seed)
    results: dict = {}
    fitted_estimators: dict = {}

    for name, spec in variants.items():
        feature_set = spec["features"]
        if "embeddings" in feature_set and not embeddings_available:
            continue

        X_train = _assemble_matrix(feature_set, tfidf_train, engineered_train_scaled, embeddings_train)
        X_test = _assemble_matrix(feature_set, tfidf_test, engineered_test_scaled, embeddings_test)

        estimator = spec["estimator"]
        estimator.fit(X_train, y_train)

        y_pred = estimator.predict(X_test)
        y_proba = _predict_fake_probability(estimator, X_test)
        metrics = compute_metrics(y_test, y_pred, y_proba)

        cv_f1_mean = None
        if feature_set == ("tfidf",):
            cv_f1_mean = _cross_validate_tfidf_only(
                train_texts_processed, y_train, type(estimator), seed
            )

        results[name] = {
            "metrics": metrics,
            "feature_set": feature_set,
            "cv_f1_mean": cv_f1_mean,
        }
        fitted_estimators[name] = estimator

    primary_metric = SETTINGS.training.primary_metric
    best_name = max(results, key=lambda n: results[n]["metrics"].get(primary_metric) or 0.0)
    best_estimator = fitted_estimators[best_name]
    best_feature_set = results[best_name]["feature_set"]

    _save_artifacts(
        best_name=best_name,
        estimator=best_estimator,
        tfidf=tfidf,
        scaler=scaler,
        feature_set=best_feature_set,
        results=results,
        full_df=df,
        embeddings_available=embeddings_available,
    )

    return {"results": results, "best_model": best_name, "feature_set": best_feature_set}


def _save_artifacts(
    best_name: str,
    estimator,
    tfidf: TfidfVectorizer,
    scaler: StandardScaler,
    feature_set: tuple,
    results: dict,
    full_df: pd.DataFrame,
    embeddings_available: bool,
) -> None:
    joblib.dump(estimator, CLASSIFIER_PATH)
    joblib.dump(tfidf, VECTORIZER_PATH)
    joblib.dump(scaler, FEATURE_SCALER_PATH)

    feature_config = {
        "feature_set": list(feature_set),
        "engineered_feature_names": ENGINEERED_FEATURE_NAMES,
        "embedding_model": SETTINGS.embedding.model_name if "embeddings" in feature_set else None,
        "best_model": best_name,
    }
    FEATURE_CONFIG_PATH.write_text(json.dumps(feature_config, indent=2))

    class_distribution = {str(k): int(v) for k, v in full_df["label"].value_counts().items()}

    metadata = {
        "best_model": best_name,
        "feature_set": list(feature_set),
        "dataset_size": int(len(full_df)),
        "class_distribution": class_distribution,
        "is_demo_dataset": bool(len(full_df) < 200),
        "results": {
            name: {
                "metrics": payload["metrics"],
                "feature_set": list(payload["feature_set"]),
                "cv_f1_mean": payload["cv_f1_mean"],
            }
            for name, payload in results.items()
        },
    }
    MODEL_METADATA_PATH.write_text(json.dumps(metadata, indent=2))

    similarity_texts = full_df["review"].tolist()
    if embeddings_available:
        try:
            similarity_embeddings = encode_texts(similarity_texts)
            joblib.dump(
                {"reference_texts": similarity_texts, "reference_embeddings": similarity_embeddings},
                SIMILARITY_REFERENCE_PATH,
            )
        except EmbeddingModelError:
            pass


if __name__ == "__main__":
    output = train_and_evaluate()
    print(f"Best model: {output['best_model']}")
    for model_name, payload in output["results"].items():
        print(model_name, payload["metrics"])
