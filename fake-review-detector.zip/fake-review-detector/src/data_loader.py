"""Dataset loading, column detection and cleaning utilities."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

import pandas as pd

from src.config import (
    LABEL_COLUMN_CANDIDATES,
    REVIEW_COLUMN_CANDIDATES,
    SAMPLE_DATASET_PATH,
)


class DatasetError(Exception):
    """Raised when a dataset cannot be loaded or is structurally invalid."""


def _find_column(columns: list[str], candidates: tuple[str, ...]) -> Optional[str]:
    lowered = {col.lower().strip(): col for col in columns}
    for candidate in candidates:
        if candidate in lowered:
            return lowered[candidate]
    return None


def detect_columns(df: pd.DataFrame) -> tuple[str, Optional[str]]:
    """Find the review text column and, if present, the label column."""
    review_col = _find_column(list(df.columns), REVIEW_COLUMN_CANDIDATES)
    if review_col is None:
        raise DatasetError(
            "Could not find a review text column. Expected one of: "
            f"{', '.join(REVIEW_COLUMN_CANDIDATES)}"
        )
    label_col = _find_column(list(df.columns), LABEL_COLUMN_CANDIDATES)
    return review_col, label_col


def load_dataset(path: Optional[Path] = None) -> pd.DataFrame:
    """Load a CSV dataset, falling back to the bundled demo dataset.

    Returns a dataframe with standardized ``review`` and ``label`` columns.
    """
    dataset_path = Path(path) if path is not None else None

    if dataset_path is None or not dataset_path.exists():
        dataset_path = SAMPLE_DATASET_PATH

    if not dataset_path.exists():
        raise DatasetError(f"Dataset not found at {dataset_path}")

    try:
        df = pd.read_csv(dataset_path)
    except Exception as exc:  # noqa: BLE001
        raise DatasetError(f"Failed to parse CSV at {dataset_path}: {exc}") from exc

    if df.empty:
        raise DatasetError(f"Dataset at {dataset_path} is empty")

    review_col, label_col = detect_columns(df)

    standardized = pd.DataFrame()
    standardized["review"] = df[review_col]
    if label_col is not None:
        standardized["label"] = df[label_col]

    return standardized


_HTML_TAG_PATTERN = re.compile(r"<[^>]+>")
_URL_PATTERN = re.compile(r"https?://\S+|www\.\S+")
_MULTI_SPACE_PATTERN = re.compile(r"\s+")


def _strip_html(text: str) -> str:
    return _HTML_TAG_PATTERN.sub(" ", text)


def _strip_urls(text: str) -> str:
    return _URL_PATTERN.sub(" ", text)


def _normalize_whitespace(text: str) -> str:
    return _MULTI_SPACE_PATTERN.sub(" ", text).strip()


def clean_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Clean a review dataset, removing invalid or duplicate rows.

    Punctuation is intentionally preserved because it carries signal for
    fake-review detection (excessive exclamation marks, etc).
    """
    cleaned = df.copy()

    cleaned["review"] = cleaned["review"].astype(str)
    cleaned = cleaned[cleaned["review"].str.lower() != "nan"]

    cleaned["review"] = cleaned["review"].apply(_strip_html)
    cleaned["review"] = cleaned["review"].apply(_strip_urls)
    cleaned["review"] = cleaned["review"].apply(_normalize_whitespace)

    cleaned = cleaned[cleaned["review"].str.len() > 0]

    if "label" in cleaned.columns:
        cleaned = cleaned.dropna(subset=["label"])
        cleaned["label"] = pd.to_numeric(cleaned["label"], errors="coerce")
        cleaned = cleaned.dropna(subset=["label"])
        cleaned = cleaned[cleaned["label"].isin([0, 1])]
        cleaned["label"] = cleaned["label"].astype(int)

    cleaned = cleaned.drop_duplicates(subset=["review"])
    cleaned = cleaned.reset_index(drop=True)

    return cleaned


def load_and_clean(path: Optional[Path] = None) -> pd.DataFrame:
    """Convenience wrapper combining ``load_dataset`` and ``clean_dataset``."""
    df = load_dataset(path)
    return clean_dataset(df)
