"""Similarity detection between a candidate review and a reference set."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class SimilarityResult:
    highest_score: float
    most_similar_review: str | None
    top_matches: list[tuple[str, float]]


class SimilarityIndex:
    """Holds reference review embeddings and answers similarity queries."""

    def __init__(self, reference_texts: list[str], reference_embeddings: np.ndarray):
        self.reference_texts = list(reference_texts)
        self.reference_embeddings = reference_embeddings

    def is_empty(self) -> bool:
        return len(self.reference_texts) == 0

    def query(self, embedding: np.ndarray, top_k: int = 3) -> SimilarityResult:
        if self.is_empty():
            return SimilarityResult(highest_score=0.0, most_similar_review=None, top_matches=[])

        embedding = embedding.reshape(1, -1)
        scores = cosine_similarity(embedding, self.reference_embeddings)[0]

        order = np.argsort(scores)[::-1][:top_k]
        top_matches = [(self.reference_texts[i], round(float(scores[i]), 4)) for i in order]

        best_idx = int(order[0])
        return SimilarityResult(
            highest_score=round(float(scores[best_idx]), 4),
            most_similar_review=self.reference_texts[best_idx],
            top_matches=top_matches,
        )

    def to_dict(self) -> dict:
        return {
            "reference_texts": self.reference_texts,
            "reference_embeddings": self.reference_embeddings,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SimilarityIndex":
        return cls(data["reference_texts"], data["reference_embeddings"])
