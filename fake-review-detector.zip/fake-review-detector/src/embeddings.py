"""Sentence embedding generation backed by Sentence Transformers.

The model is loaded once per process and reused across calls so that a
Streamlit session or a training run never pays the load cost twice.
"""

from __future__ import annotations

import functools
from typing import Iterable

import numpy as np

from src.config import SETTINGS


class EmbeddingModelError(Exception):
    """Raised when the sentence embedding model cannot be loaded."""


@functools.lru_cache(maxsize=1)
def _get_model(model_name: str):
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:  # noqa: BLE001
        raise EmbeddingModelError(
            "sentence-transformers is not installed. Run "
            "'pip install sentence-transformers' to enable embeddings."
        ) from exc

    try:
        return SentenceTransformer(model_name)
    except Exception as exc:  # noqa: BLE001
        raise EmbeddingModelError(
            f"Failed to load embedding model '{model_name}': {exc}"
        ) from exc


def get_embedding_model(model_name: str | None = None):
    """Return the cached sentence embedding model."""
    return _get_model(model_name or SETTINGS.embedding.model_name)


def encode_texts(
    texts: Iterable[str],
    model_name: str | None = None,
    batch_size: int | None = None,
) -> np.ndarray:
    """Encode a batch of raw texts into semantic embedding vectors."""
    model = get_embedding_model(model_name)
    texts = list(texts)
    if not texts:
        return np.empty((0, model.get_sentence_embedding_dimension()))

    embeddings = model.encode(
        texts,
        batch_size=batch_size or SETTINGS.embedding.batch_size,
        show_progress_bar=False,
        normalize_embeddings=SETTINGS.embedding.normalize_embeddings,
        convert_to_numpy=True,
    )
    return embeddings


def encode_single(text: str, model_name: str | None = None) -> np.ndarray:
    """Encode a single review, returning a 1D embedding vector."""
    return encode_texts([text], model_name=model_name)[0]
