"""Statistical and linguistic feature engineering for raw review text."""

from __future__ import annotations

import re
import string

import numpy as np
import pandas as pd

from src.preprocessing import clean_for_display, tokenize

_SENTENCE_SPLIT_PATTERN = re.compile(r"[.!?]+")
_URL_PATTERN = re.compile(r"https?://\S+|www\.\S+")
_EMOJI_PATTERN = re.compile(
    "["
    "\U0001F300-\U0001FAFF"
    "\U00002600-\U000027BF"
    "\U0001F1E6-\U0001F1FF"
    "]+",
    flags=re.UNICODE,
)

FEATURE_NAMES = [
    "char_count",
    "word_count",
    "sentence_count",
    "avg_word_length",
    "unique_word_ratio",
    "repeated_word_ratio",
    "uppercase_char_count",
    "uppercase_ratio",
    "digit_count",
    "punctuation_count",
    "exclamation_count",
    "question_count",
    "url_count",
    "emoji_count",
    "avg_sentence_length",
]


def _sentence_count(text: str) -> int:
    sentences = [s for s in _SENTENCE_SPLIT_PATTERN.split(text) if s.strip()]
    return max(len(sentences), 1)


def extract_features(raw_text: str) -> dict:
    """Compute the full statistical/linguistic feature set for one review."""
    text = clean_for_display(raw_text)
    words = tokenize(text) if text else []
    word_tokens = [w for w in words if w.strip()]
    lower_words = [w.lower() for w in word_tokens]

    char_count = len(text)
    word_count = len(word_tokens)
    sentence_count = _sentence_count(text)

    avg_word_length = (
        sum(len(w) for w in word_tokens) / word_count if word_count else 0.0
    )

    unique_words = set(lower_words)
    unique_word_ratio = len(unique_words) / word_count if word_count else 0.0

    if word_count:
        counts = pd.Series(lower_words).value_counts()
        repeated = counts[counts > 1].sum()
        repeated_word_ratio = repeated / word_count
    else:
        repeated_word_ratio = 0.0

    uppercase_char_count = sum(1 for c in text if c.isupper())
    uppercase_ratio = uppercase_char_count / char_count if char_count else 0.0

    digit_count = sum(1 for c in text if c.isdigit())
    punctuation_count = sum(1 for c in text if c in string.punctuation)
    exclamation_count = text.count("!")
    question_count = text.count("?")
    url_count = len(_URL_PATTERN.findall(raw_text))
    emoji_count = len(_EMOJI_PATTERN.findall(raw_text))

    avg_sentence_length = word_count / sentence_count if sentence_count else 0.0

    return {
        "char_count": char_count,
        "word_count": word_count,
        "sentence_count": sentence_count,
        "avg_word_length": round(avg_word_length, 4),
        "unique_word_ratio": round(unique_word_ratio, 4),
        "repeated_word_ratio": round(repeated_word_ratio, 4),
        "uppercase_char_count": uppercase_char_count,
        "uppercase_ratio": round(uppercase_ratio, 4),
        "digit_count": digit_count,
        "punctuation_count": punctuation_count,
        "exclamation_count": exclamation_count,
        "question_count": question_count,
        "url_count": url_count,
        "emoji_count": emoji_count,
        "avg_sentence_length": round(avg_sentence_length, 4),
    }


def extract_features_batch(texts: pd.Series) -> pd.DataFrame:
    """Vectorized-friendly feature extraction over a batch of raw reviews."""
    records = [extract_features(text) for text in texts]
    return pd.DataFrame.from_records(records, columns=FEATURE_NAMES)


def features_to_array(features: dict) -> np.ndarray:
    return np.array([[features[name] for name in FEATURE_NAMES]], dtype=float)
