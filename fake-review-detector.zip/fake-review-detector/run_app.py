"""Convenience launcher: python -m streamlit run run_app.py

This file simply forwards to the Streamlit application defined in
app/app.py so the project can be started from the repository root.
"""

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.app import main  # noqa: E402

if __name__ == "__main__":
    main()
