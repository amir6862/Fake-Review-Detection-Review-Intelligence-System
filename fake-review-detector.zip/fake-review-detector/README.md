# Fake Review Detection & Review Intelligence System

A complete, production-style Python machine learning and NLP application that
estimates whether an online review resembles patterns typically associated
with fake or genuine reviews. The system combines TF-IDF features, sentence
embeddings, statistical and linguistic features, sentiment analysis, review
similarity, and rule-based indicators, and exposes the result through a
Streamlit dashboard.

The system does not claim to determine with certainty whether a review is
fake. It reports a probability that reflects patterns learned from labeled
training data.

---

## Features

- Text preprocessing pipeline shared identically between training and prediction
- TF-IDF feature extraction (unigrams and bigrams)
- Sentence embeddings via Sentence Transformers
- Statistical and linguistic feature engineering (15+ features)
- Sentiment analysis (polarity and subjectivity)
- Review similarity detection against a reference collection
- Rule-based suspicious pattern detection
- Multiple ML models trained and compared automatically (Logistic Regression,
  Linear SVM, Multinomial Naive Bayes, Random Forest, XGBoost, and combined
  feature variants)
- Automatic best-model selection using F1-score with a held-out test set
- Feature-level explanations for linear model predictions
- Streamlit application: Home, Review Analyzer, Model Information,
  Batch Analysis, and Dashboard pages
- Batch analysis of an uploaded CSV with downloadable results
- Unit tests covering preprocessing, features, similarity, and prediction

---

## Technology Stack

- Python 3.10+
- pandas, numpy, scipy
- scikit-learn, xgboost
- nltk, textblob
- sentence-transformers
- Streamlit
- matplotlib, seaborn, plotly
- pytest

---

## Project Architecture

```
fake-review-detector/
├── app/
│   ├── app.py                  Streamlit entry point
│   └── components/
│       ├── analyzer.py         Review Analyzer and Batch Analysis pages
│       ├── dashboard.py        Model Information and Dashboard pages
│       └── ui.py                Shared styling and UI helpers
│
├── data/
│   ├── raw/                    Place your real dataset here (reviews.csv)
│   ├── processed/               Reserved for intermediate processed data
│   └── sample/                  Bundled demo dataset
│
├── models/
│   ├── classifier/               Trained classifier, feature config, metadata
│   ├── vectorizer/               Fitted TF-IDF vectorizer and feature scaler
│   └── embeddings/               Similarity reference embeddings
│
├── notebooks/
│   ├── 01_eda.ipynb
│   ├── 02_preprocessing.ipynb
│   ├── 03_feature_engineering.ipynb
│   ├── 04_tfidf_models.ipynb
│   ├── 05_embeddings.ipynb
│   └── 06_model_comparison.ipynb
│
├── src/
│   ├── config.py                Central configuration
│   ├── data_loader.py           Dataset loading and cleaning
│   ├── preprocessing.py         Reusable NLP preprocessing
│   ├── feature_engineering.py   Statistical and linguistic features
│   ├── sentiment.py             Sentiment analysis
│   ├── embeddings.py            Sentence embedding generation
│   ├── similarity.py            Review similarity index
│   ├── train.py                 Training pipeline and model comparison
│   ├── evaluate.py              Metrics and reporting
│   ├── predict.py               Single reusable prediction pipeline
│   └── explainability.py        Suspicious indicators and feature attribution
│
├── tests/                       pytest unit tests
├── scripts/
│   ├── train_model.py           CLI training entry point
│   └── evaluate_model.py        CLI evaluation entry point
│
├── requirements.txt
├── README.md
├── .gitignore
└── run_app.py
```

---

## Dataset Format

The training pipeline expects a CSV file with a review text column and a
label column. Column names are auto-detected from common variations.

Recognized review column names: `review`, `review_text`, `text`, `content`, `comment`

Recognized label column names: `label`, `is_fake`, `fake`, `target`, `class`

Label convention:

- `0` = Genuine
- `1` = Fake

Example:

```csv
review,label
"The product works very well",0
"Absolutely perfect product, everyone must buy it",1
```

If no dataset is placed in `data/raw/`, the training script automatically
falls back to the small bundled demo dataset in `data/sample/`. The demo
dataset exists only to exercise the pipeline end to end; it is not large
enough or representative enough to produce meaningful real-world accuracy.
Replace `data/raw/reviews.csv` with a real, larger, labeled dataset before
drawing any conclusions from the model's predictions.

---

## Installation

### Windows

```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

### Linux / macOS

```
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

The first run that uses sentence embeddings or sentiment analysis will
download supporting model files and NLTK corpora. This requires internet
access. If no internet access is available, the application still runs:
embedding-based features and similarity detection are skipped automatically,
and preprocessing falls back to simpler tokenization.

---

## Training the Model

Train on the bundled demo dataset:

```
python scripts/train_model.py
```

Train on your own dataset:

```
python scripts/train_model.py --dataset data/raw/reviews.csv
```

Training performs the following steps: data cleaning, a train/test split
(before any preprocessing component is fit), TF-IDF vectorization,
statistical and sentiment feature engineering, optional sentence embeddings,
training of several candidate models, evaluation on the held-out test set,
and automatic selection of the best model by F1-score. All artifacts are
saved to the `models/` directory, and the training script prints a
comparison table across every model that was evaluated.

---

## Evaluating the Trained Model

```
python scripts/evaluate_model.py
```

This prints the currently selected model, its feature set, dataset
statistics, and the full model comparison table from the last training run,
without retraining anything.

---

## Running the Application

```
python -m streamlit run app/app.py
```

or, from the project root:

```
python -m streamlit run run_app.py
```

The application will not train a model automatically. If no trained model
is found, the Review Analyzer and Batch Analysis pages display a message
asking you to run `scripts/train_model.py` first.

---

## Using the Review Analyzer

1. Open the Streamlit application.
2. Go to the "Review Analyzer" page.
3. Paste or type a review into the text area.
4. Click "Analyze Review".
5. Review the prediction, fake/genuine probability, sentiment, statistics,
   similarity score, suspicious indicators, and important features.

### Example Input

```
This product is absolutely amazing. It is the best product I have ever
purchased. Everyone should buy this product immediately.
```

### Example Output

```
Prediction: Likely Fake
Fake Probability: 71.0%
Genuine Probability: 29.0%
Suspicious indicators: Strong promotional language, Excessive punctuation
```

---

## Batch Analysis Instructions

1. Go to the "Batch Analysis" page.
2. Upload a CSV file containing a review column (see recognized column
   names above).
3. Click "Run Batch Analysis".
4. Review the results table.
5. Click "Download Results CSV" to save predictions for every row.

Uploaded files are treated as untrusted input: file type, size, required
columns, and empty or malformed data are all validated before processing.

---

## Running Tests

```
pytest tests/
```

or with more detail:

```
pytest tests/ -v
```

---

## Project Limitations

- The bundled demo dataset is small and synthetic. Metrics produced from it
  do not represent real-world performance and should not be used to judge
  the system's accuracy.
- The system reports probabilities based on learned patterns; it cannot
  verify the authenticity of a review with certainty.
- Sentence embeddings and similarity detection require downloading a
  Sentence Transformers model on first use, which requires internet access.
  If unavailable, these features degrade gracefully and are skipped.
- Suspicious pattern indicators are heuristic and are intended as supporting
  evidence, not proof of deception.
- The similarity reference collection is built from the training dataset at
  training time. It does not update automatically as new reviews are
  analyzed.

---

## Future Improvements

- Support for incremental updates to the similarity reference collection
- Multilingual preprocessing and model support
- Active learning workflow for labeling ambiguous reviews
- Model monitoring and drift detection for production deployments
- Richer explainability for non-linear models (e.g. SHAP values)

---

## Deployment Instructions

The application is a standard Streamlit app and can be deployed to any
environment that supports Python and outbound network access for model
downloads (Streamlit Community Cloud, a container on a cloud provider, or
an internal server).

General steps:

1. Provide a trained model by running `scripts/train_model.py` as part of
   your build process, or by shipping the `models/` directory alongside the
   code.
2. Install dependencies from `requirements.txt`.
3. Start the app with `python -m streamlit run app/app.py --server.port <port> --server.address 0.0.0.0`.
4. Ensure the deployment environment has enough memory to hold the TF-IDF
   vectorizer and, if used, the sentence embedding model in memory.

Do not retrain the model on every application startup; training is a
separate, explicit step.

---

## Troubleshooting

**"No trained model was found" in the app**
Run `python scripts/train_model.py` from the project root before starting
the Streamlit app.

**Embedding model fails to load / similarity score is always 0**
This usually means the environment does not have internet access to
download the Sentence Transformers model, or `sentence-transformers` is not
installed. The application continues to work using TF-IDF and engineered
features; similarity detection is simply unavailable until the embedding
model can be downloaded.

**NLTK resource errors during preprocessing**
The preprocessing module attempts to download required NLTK resources
(`punkt`, `stopwords`, `wordnet`) automatically on first use. If your
environment has no internet access, preprocessing falls back to simpler
tokenization and skips lemmatization rather than failing.

**CSV upload fails in Batch Analysis**
Confirm the file is a valid CSV and contains a column with a recognized
review column name (see Dataset Format above).

**Training fails with "must contain both genuine (0) and fake (1) examples"**
Your dataset's label column must contain both `0` and `1` values. Check
that the label column was detected correctly and that labels are numeric.

**Streamlit app is slow on first prediction**
The first prediction in a session loads the classifier, vectorizer, and
(if configured) the embedding model into memory. Subsequent predictions in
the same session reuse the cached objects and are much faster.
